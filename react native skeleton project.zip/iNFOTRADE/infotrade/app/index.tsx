import { Text, View } from "react-native";
import Component_search_box from "./components/search";

export default function Index() {
  return (
    <View
      className="flex flex-col gap-2 items-center  h-full w-full"
    >
      <Component_search_box
        onChange={(e: any) => console.log(e.target.value)} 
      />
      <Text >Edit app/index.tsx to edit this screen.</Text>
    </View>
  );
}
