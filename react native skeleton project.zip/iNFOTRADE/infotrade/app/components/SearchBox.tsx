import { View, TextInput } from "react-native";

interface SearchBoxProps {
    onChange: (text: string) => void;
}

export default function SearchBox({ onChange }: SearchBoxProps) {
    return (
        <View>
            <TextInput 
                placeholder="Search" 
                onChangeText={onChange}
                className="border p-2 rounded-md w-full"
            />
        </View>
    );
}
