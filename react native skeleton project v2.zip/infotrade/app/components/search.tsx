import { View, TextInput, Image } from "react-native";
import FilterSvg from '../../assets/images/search_filter.svg'
import SearchIcon  from "../../assets/images/search_icon.svg";
function component_search_box(
    
    props:{
        onChange: (e: any) => void
    }
){

   //ochange 
//    const onChange = (e: any) => {
//        console.log(e.target.value);
//    }

    return(
        <View
            className="w-full h-[7%] w-full  flex items-center "
        >
            <View className="w-[80%] h-full flex flex-row items-center border border-black rounded-[18px] pl-4 pr-4 text-black bg-white">
                <SearchIcon />
                <TextInput placeholder="Search" onChange={props.onChange}
                    className="w-[80%] h-full p-4 text-[19px] font-[600] placeholder:text-[#3C2F2F] "
                />
                <FilterSvg />
            </View>
        </View>
    )
}

export default component_search_box  