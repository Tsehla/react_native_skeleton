import { View } from "react-native";
import Home_nav from "../../assets/images/1_nav_home.svg";

function nav_bottom() {
    return (
        <View className="w-full h-[20%] flex items-center justify-center">
            <Home_nav 
                // className="border-t border-white "
                width={'100%'} 
                height={'100%'}
               
            />
        </View>
    );
}

export default nav_bottom