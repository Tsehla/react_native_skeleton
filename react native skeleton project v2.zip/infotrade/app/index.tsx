import { Text, View } from "react-native";
import { LinearGradient } from 'expo-linear-gradient';
import Component_search_box from "./components/search";
import Nav_bottom from "./components/nav_bottom";

// home
import Sell_now_home from "../assets/images/sell_now_home.svg";

export default function Index() {

    function search_box(value: string){
      alert("search_box, go to search page :: " + value);
    }



  return (



    <LinearGradient
      colors={['#2E1371', '#130B2B']}
      className="flex-1 w-full"
      start={{ x: 0, y: 0 }}
      end={{ x: 0, y: 1 }}
    >

      {/* header */}
      <View  className="flex items-center justify-center w-full h-[7%] mt-5 text-2xl text-white">
        <Text
          className="text-2xl text-white"
          style={{
            fontFamily: "Poppins-Bold",
          }}
        >iNFOTRADE</Text>
      </View>

      {/* search box */}
      <Component_search_box
        onChange={(e: any) => search_box(e.target.value)} 
      />
      

      <View
      className=" flex items-center justify-center w-full h-[70%] mt-2 text-2xl p-2 text-white"
      >
          <Sell_now_home 
            width={'100%'} 
            height={'100%'}
          />
      </View>

      <Nav_bottom />
    </LinearGradient>
  );
}
