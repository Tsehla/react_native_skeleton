import { Stack } from "expo-router";
import { useFonts } from 'expo-font';
import { useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import * as SplashScreen from 'expo-splash-screen';
import "../global.css";

// Keep the splash screen visible while we fetch resources
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    'PostNoBillsJaffna-Bold': require('../assets/fonts/PostNoBillsJaffna/PostNoBillsJaffna-Bold.ttf'),
  });
  const [fontsLoaded2] = useFonts({
    'Poppins-Bold': require('../assets/fonts/Poppins/Poppins-Bold.ttf'),
  });

  useEffect(() => {
    if (fontsLoaded && fontsLoaded2) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontsLoaded2]);

  if (!fontsLoaded || !fontsLoaded2) {
    return null; // Or a loading indicator
  }

  return (
    <SafeAreaProvider>
      <Stack>
        <Stack.Screen name="index" options={{ headerShown: false }} />
      </Stack>
    </SafeAreaProvider>
  );
}
