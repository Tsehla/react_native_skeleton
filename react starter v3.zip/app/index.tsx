import React from 'react';
import { Text, View } from 'react-native';


export default function index(){







  return (
    <View>
      <Text>index</Text>
    </View>
  );
}